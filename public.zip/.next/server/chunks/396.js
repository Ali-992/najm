"use strict";
exports.id = 396;
exports.ids = [396];
exports.modules = {

/***/ 6625:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Contact)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_Title__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(251);
/* harmony import */ var _ui_ContactItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1440);
/* harmony import */ var _utils_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ui_Title__WEBPACK_IMPORTED_MODULE_3__]);
_ui_Title__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Contact() {
    const { en  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_store__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
    const { 0: status , 1: setStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        submitted: false,
        submitting: false,
        info: {
            error: false,
            msg: null
        }
    });
    const { 0: inputs1 , 1: setInputs  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        companyName: "",
        email: "",
        message: ""
    });
    const handleOnChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        e.persist();
        setInputs((inputs)=>({
                ...inputs,
                [e.target.id]: e.target.value
            })
        );
        setStatus({
            submitted: false,
            submitting: false,
            info: {
                error: false,
                msg: null
            }
        });
    }, []);
    const handleServerResponse = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((ok, message)=>{
        if (ok) {
            setStatus({
                submitted: true,
                submitting: false,
                info: {
                    error: false,
                    msg: null
                }
            });
            setInputs({
                companyName: "",
                email: "",
                message: ""
            });
        } else {
            setStatus({
                submitted: false,
                submitting: false,
                info: {
                    error: true,
                    msg: "Something went wrong. Please try again later."
                }
            });
        }
    }, []);
    const handleSubmit = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        e.preventDefault();
        setStatus((prevStatus)=>({
                ...prevStatus,
                submitting: true
            })
        );
        axios__WEBPACK_IMPORTED_MODULE_2___default()({
            method: "POST",
            url: "https://formspree.io/f/xvolylno",
            data: inputs1
        }).then((_response)=>handleServerResponse(true, "Thank You , Message sent successfully")
        );
    }, [
        inputs1,
        handleServerResponse
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-dark3 px-4 py-2 sm:px-6 md:py-8 lg:px-12",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `section-height mx-auto max-w-7xl ${en ? "" : "rtl"}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_Title__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    children: en ? "Contact Us" : "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-12 flex flex-col gap-12 md:flex-row lg:mt-16",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid w-1/2 grid-cols-1 gap-2 lg:grid-cols-2 lg:gap-12",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    heading: en ? "Call Us" : "\u0627\u062A\u0635\u0644 \u0628\u0646\u0627",
                                    contactMethod: en ? "Call Us" : "\u062C\u0648\u0627\u0644",
                                    contactValue: en ? "+966-0530133103" : "966-0530133103+",
                                    contactValue2: en ? "+966-0508597312" : "966-0508597312+"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    heading: en ? "Mail Us" : "\u0627\u0631\u0633\u0644 \u0644\u0646\u0627",
                                    contactMethod: en ? "Email" : "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0627\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
                                    contactValue: "Info@najmalmashriq.sa",
                                    contactValue2: "Sales@najmalmashriq.sa",
                                    contactValue3: "accounts@najmalmashriq.sa"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    heading: en ? "Our Location" : "\u0645\u0648\u0642\u0639\u0646\u0627",
                                    contactMethod: en ? "Address" : "\u0627\u0644\u0639\u0646\u0648\u0627\u0646",
                                    contactValue: en ? "Kingdome of Saudi Arabia - Riyadh" : "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 - \u0627\u0644\u0631\u064A\u0627\u0636"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_ContactItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    heading: en ? "P.O.Box" : "\u0627\u0644\u0628\u0631\u064A\u062F",
                                    contactMethod: ` `,
                                    contactValue: "14331 "
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col",
                                    children: " "
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: "flex w-full flex-col gap-4 md:w-1/2",
                            onSubmit: handleSubmit,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-lg font-bold leading-7 md:text-xl",
                                        children: en ? "Get in Touch" : "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627"
                                    })
                                }),
                                " ",
                                status.info.error && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative rounded border border-red-400 bg-red-100 px-4 py-3 text-red-700",
                                    role: "alert",
                                    children: [
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            className: "font-bold",
                                            children: "Error"
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "block sm:inline",
                                            children: status.info.msg
                                        }),
                                        " "
                                    ]
                                }),
                                " ",
                                status.submitted ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative rounded px-4 py-3 text-xl font-bold text-white",
                                    role: "alert",
                                    children: [
                                        " ",
                                        "Your message has been sent successfully. We will Contact you soon.",
                                        " "
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            id: "companyName",
                                            name: "Company Name",
                                            required: true,
                                            maxLength: 128,
                                            placeholder: en ? "Company Name" : "\u0627\u0633\u0645 \u0627\u0644\u0634\u0631\u0643\u0629",
                                            className: "rounded-3xl border-2 border-white bg-black px-8 py-2 text-white outline-none",
                                            onChange: handleOnChange,
                                            value: inputs1.companyName
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "email",
                                            name: "email",
                                            id: "email",
                                            required: true,
                                            maxLength: 200,
                                            placeholder: en ? "Your Email" : "\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0627\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
                                            className: "rounded-3xl border-2 border-white bg-black px-8 py-2 text-white outline-none",
                                            onChange: handleOnChange,
                                            value: inputs1.email
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            name: "message",
                                            id: "message",
                                            cols: "30",
                                            rows: "10",
                                            required: true,
                                            maxLength: 1048576,
                                            placeholder: en ? "Your Message" : "\u0627\u0644\u0631\u0633\u0627\u0644\u0629",
                                            className: "min-h-[16em] rounded-3xl border-2 border-white bg-black px-8 py-6 text-white outline-none",
                                            onChange: handleOnChange,
                                            value: inputs1.message
                                        }),
                                        " ",
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt-10 text-center",
                                            children: [
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    type: "submit",
                                                    className: "rounded-3xl bg-black px-8 py-2 text-white",
                                                    children: [
                                                        " ",
                                                        !status.submitting ? !status.submitted ? `${en ? "Submit" : "\u0627\u0631\u0633\u0627\u0644"}` : `${en ? "Submitted" : "\u062A\u0645 \u0627\u0644\u0627\u0631\u0633\u0627\u0644"}` : `${en ? "Submitting" : "\u062C\u0627\u0631\u064A \u0627\u0644\u0627\u0631\u0633\u0627\u0644"}`,
                                                        " "
                                                    ]
                                                }),
                                                " "
                                            ]
                                        }),
                                        " "
                                    ]
                                }),
                                " "
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2765);





function Footer() {
    const { en  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: ` ${en ? "" : "rtl"} bg-zinc-100`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "footer mx-auto max-w-7xl p-10 px-4 py-2 md:px-6 md:py-8 lg:px-8",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: en ? "/images/logo-EN-black.png" : "/images/logo-AR-black.png",
                                width: 320,
                                height: 80
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "mt-2 capitalize",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "text-heading",
                                        children: en ? "Najm Al Mashriq" : "\u0646\u062C\u0645 \u0627\u0644\u0645\u0634\u0631\u0642"
                                    }),
                                    " ",
                                    en ? "Contracting Company" : "\u0644\u0644\u0645\u0642\u0627\u0648\u0644\u0627\u062A"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "capitalize",
                                children: [
                                    " ",
                                    en ? "Rental Of light and heavy equipment" : " \u0648 \u062A\u0623\u062C\u064A\u0631 \u0627\u0644\u0645\u0639\u062F\u0627\u062A",
                                    " "
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "footer-title",
                                children: en ? "Services" : "\u062E\u062F\u0645\u0627\u062A\u0646\u0627"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/equipments",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "link link-hover",
                                    children: [
                                        " ",
                                        en ? "Heavy Equipements Rental" : "\u0627\u064A\u062C\u0627\u0631 \u0627\u0644\u0645\u0639\u062F\u0627\u062A \u0627\u0644\u062B\u0642\u064A\u0644\u0629",
                                        " "
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/equipments",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "link link-hover",
                                    children: [
                                        " ",
                                        en ? "Rental of cranes" : "\u0627\u064A\u062C\u0627\u0631 \u0627\u0644\u0631\u0627\u0641\u0639\u0627\u062A",
                                        " "
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/services",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "link link-hover",
                                    children: en ? "General construction of residential building" : "\u0627\u0646\u0634\u0627\u0621 \u0627\u0644\u0645\u0628\u0627\u0646\u064A \u0627\u0644\u0633\u0643\u0646\u064A\u0629"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/services",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: "link link-hover",
                                    children: [
                                        " ",
                                        en ? "Residential and non-residential building renovations" : "\u062A\u062C\u062F\u064A\u062F \u0627\u0644\u0645\u0628\u0627\u0646\u064A \u0627\u0644\u0633\u0643\u0646\u064A\u0629 \u0648\u063A\u064A\u0631 \u0627\u0644\u0633\u0643\u0646\u064A\u0629"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "footer-title",
                                children: en ? "Company" : "\u0627\u0644\u0634\u0631\u0643\u0629"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "link link-hover",
                                    children: en ? "Home" : "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/about",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "link link-hover",
                                    children: en ? "About Us" : "\u0645\u0646 \u0646\u062D\u0646"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/contact",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "link link-hover",
                                    children: en ? "Contact" : "\u0644\u0644\u062A\u0648\u0627\u0635\u0644"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-zinc-100 text-center md:py-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "text-sm",
                    children: [
                        "\xa9 ",
                        new Date().getFullYear(),
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                            className: "text-heading",
                            children: "Najm Al Mashriq"
                        }),
                        ". All rights reserved."
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 4180:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var _ui_NavLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8776);
/* harmony import */ var _ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7272);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Nav() {
    const { en , changeLang  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_store__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z);
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed top-0 left-0 z-20 w-full bg-gray-800",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: `mx-auto max-w-7xl ${en ? "" : "rtl"}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex h-24 items-center justify-between ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex w-full items-center justify-between ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: "/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-[180px] cursor-pointer overflow-hidden lg:h-[56px] lg:w-[360px]",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: en ? "/images/logo-white.png" : "/images/logo-white-ar.png",
                                                alt: "Najm AlMashriq",
                                                className: "h-full w-full"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden md:block",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-baseline space-x-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    navName: en ? "Home" : "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
                                                    link: "/"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    navName: en ? "About Us" : "\u0645\u0646 \u0646\u062D\u0646",
                                                    link: "/about"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    navName: en ? "Services" : "\u062E\u062F\u0645\u0627\u062A\u0646\u0627",
                                                    link: "/services"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    navName: en ? "Equipments" : "\u0645\u0639\u062F\u0627\u062A",
                                                    link: "/equipments"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    navName: en ? "Contact" : "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627",
                                                    link: "/contact"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                    onClick: changeLang,
                                                    className: "btn min-w-[60px] bg-heading text-white hover:bg-white hover:text-black",
                                                    children: [
                                                        " ",
                                                        en ? "\u0639" : "en",
                                                        " "
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "-mr-2 flex gap-4 md:hidden",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: changeLang,
                                        className: "btn min-w-[60px] bg-heading text-white hover:bg-heading hover:text-white",
                                        children: [
                                            " ",
                                            en ? "\u0639" : "en",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: ()=>setIsOpen(!isOpen)
                                        ,
                                        type: "button",
                                        className: "inline-flex items-center justify-center rounded-md bg-gray-900 p-2 text-gray-400 hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-800",
                                        "aria-controls": "mobile-menu",
                                        "aria-expanded": "false",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "sr-only",
                                                children: "Open main menu"
                                            }),
                                            !isOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                className: "block h-6 w-6",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                stroke: "currentColor",
                                                "aria-hidden": "true",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "2",
                                                    d: "M4 6h16M4 12h16M4 18h16"
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                className: "block h-6 w-6",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 24 24",
                                                stroke: "currentColor",
                                                "aria-hidden": "true",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "2",
                                                    d: "M6 18L18 6M6 6l12 12"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                    show: isOpen,
                    enter: "transition ease-out duration-150 transform",
                    enterFrom: "opacity-0 scale-95",
                    enterTo: "opacity-100 scale-100",
                    leave: "transition ease-in duration-75 transform",
                    leaveFrom: "opacity-100 scale-100",
                    leaveTo: "opacity-0 scale-95",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "md:hidden",
                        id: "mobile-menu",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "space-y-1 px-2 pt-2 pb-3 sm:px-3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    navName: en ? "Home" : "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",
                                    link: "/"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    navName: en ? "About Us" : "\u0645\u0646 \u0646\u062D\u0646",
                                    link: "/about"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    navName: en ? "Services" : "\u062E\u062F\u0645\u0627\u062A\u0646\u0627",
                                    link: "/services"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    navName: en ? "Equipments" : "\u0645\u0639\u062F\u0627\u062A",
                                    link: "/equipments"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_NavLinksMobile__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    navName: en ? "Contact" : "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627",
                                    link: "/contact"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Nav);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3396:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Page)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(240);
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4180);
/* harmony import */ var _HomePage_Contact__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6625);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Navbar__WEBPACK_IMPORTED_MODULE_4__, _HomePage_Contact__WEBPACK_IMPORTED_MODULE_5__]);
([_Navbar__WEBPACK_IMPORTED_MODULE_4__, _HomePage_Contact__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function Page({ children , title , description  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title ? `${title} | Najm AlMashriq` : "Najm AlMashriq"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "rental heavy equipment, Riyadh equipment rental, Dammam equipment rental, Jeddah equipment rental, Jeddah equipment rental, construction services, project management, project planning, Riyad Light Towers Saudi Arabia, Large Power Generators, Rollers and compactors, Riyadh light equipment rental, Dammam lifting equipment rental, Riyadh construction Equipment, Lifting & Concrete Equipment, Parts & Attachments, Equipment Rentals, Saudi Arabia construction projects, Riyadh concrete pumps, Saudi Arabia specialized workforce, Saudi Arabia construction professionals, Jeddah construction professionals, Riyadh construction professionals, Dammam construction professionals, Cranes rental."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: description || "Looking for equipment rental ? We have all heavy and light equipment in Saudi Arabia. our large inventory includes Cranes, backhoes, excavators, Forklifts,Telehanlder,Tower Light, manlifts.."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "description",
                        content: "Looking for a heavy construction equipment rental? We rent Heavy Equipment at low Prices in Saudi Arabia. Our Large Inventory Includes Dozers, Backhoes, Excavators, Compactors, loaders.."
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Navbar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HomePage_Contact__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ContactItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function ContactItem({ heading , contactMethod , contactValue , contactValue2 , contactValue3 ,  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mb-8 flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                className: "text-lg font-bold leading-7 md:text-xl",
                children: heading
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "-mt-1 min-h-[24px] opacity-60",
                children: contactMethod
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "mt-1 leading-8 opacity-90 md:text-xl",
                children: contactValue
            }),
            " ",
            contactValue2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: " leading-8 opacity-90 md:text-xl",
                children: contactValue2
            }),
            contactValue3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: " leading-8 opacity-90 md:text-xl",
                children: contactValue3
            })
        ]
    });
};


/***/ }),

/***/ 8776:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavLink)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



function NavLink({ navName , link  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: link,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: "rounded-md px-3 py-2 text-sm font-medium text-white hover:text-heading",
            children: navName
        })
    });
};


/***/ }),

/***/ 7272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavLink)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



function NavLink({ navName , link  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: link,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
            className: "block rounded-md px-3 py-2 text-base font-medium text-gray-300 hover:bg-slate-900 hover:text-white",
            children: navName
        })
    });
};


/***/ }),

/***/ 251:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Title)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _utils_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function Title({ children  }) {
    const { en  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_store__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.h2, {
        className: "mb-8 text-2xl font-bold uppercase tracking-widest md:text-3xl",
        initial: {
            x: -100,
            opacity: 0
        },
        whileInView: {
            x: 0,
            opacity: 1
        },
        transition: {
            duration: 1,
            ease: "easeOut"
        },
        children: children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "u": () => (/* binding */ LangProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const LangContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function LangProvider({ children  }) {
    const { 0: en , 1: setEn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    function changeLang() {
        setEn(!en);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LangContext.Provider, {
        value: {
            en,
            changeLang
        },
        children: children
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LangContext);


/***/ })

};
;