import React from 'react'
import Page from '../../components/layout/Page'

export default function Contact() {
  return (
    <Page title="Contact Us">
      <div className="mt-24 text-white"></div>
    </Page>
  )
}
